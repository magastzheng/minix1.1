abort()
{
  exit(99);
}
