#include "../h/const.h"
#include "../h/type.h"

message M;
